=== Lawyer Gravity ===
Contributors: keonthemes
Tags: blog, portfolio, education, grid-Layout, two-columns, flexible-header, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, featured-images, full-width-template, post-formats, rtl-language-support, theme-options, sticky-post, threaded-comments, translation-ready
Requires at least: 4.7
Tested up to: 4.9.8
Stable tag: 1.0.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Lawyer Gravity is built for lawyers, law firms, legal advisors, private attorneys, law teaching websites and businesses, agencies and corporations.

== Description ==

Lawyer Gravity is a enhanced child theme of Business Gravity built for lawyers, law firms, legal advisors, private attorneys, law teaching websites and businesses, business consultants, agencies and corporations. Theme Demo: https://keonthemes.com/theme-demo/?id=Mjc2MnxsYXd5ZXItZ3Jhdml0eXxMYXd5ZXIgR3Jhdml0eQ=

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Lawyer Gravity includes support for WooCommerce, Contact From 7 and Jetpack.

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
* Initial release.

== Resources ==
* screenshot.png https://pixabay.com/en/pueblo-colorado-courthouse-city-1680297/ [CC0]
